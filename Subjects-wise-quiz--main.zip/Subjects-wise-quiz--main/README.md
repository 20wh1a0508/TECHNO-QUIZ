# Subjects-wise-quiz-
Here the project is subjects wise quiz
Here the students can attempt the quiz for different subjects and check their knowledge
1)Firstly we used html, css to create website initial page, signup, login.
2)Then we prepared dashboard, instructions page, subjects page and finally different subjects questions page using html and css.
3)Lastly, we connected all the pages using node js.
4)We also uploading the data i.e, filled in the sign up into firestore database for checking the email and password in login page.
CONTRIBUTORS OF THIS PROJECT IS:
1)20WH1A0541 - Ch.Keerthana
2)20WH1A0508 - G.Khadhyothi sreeja
3)20WH1A0535 - G.Poornima
//Video proof for the project execution
https://drive.google.com/file/d/1unX7ZqJ-AqpXUoLW7vKJCzdz9daly3oC/view?usp=share_link
